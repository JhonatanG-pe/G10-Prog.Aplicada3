"""
Módulo centralizado de conexión a SQL Server.
Todas las consultas del sistema pasan por aquí, para no repetir
la cadena de conexión en cada archivo.
"""
import os
import pyodbc
from dotenv import load_dotenv

# Carga las variables del archivo .env (DB_SERVER, DB_NAME, etc.)
load_dotenv()

# Driver ODBC instalado en cada PC. Se puede cambiar en el .env con
# DB_DRIVER=ODBC Driver 18 for SQL Server; si no se indica, se usa el 17.
DRIVER_POR_DEFECTO = 'ODBC Driver 17 for SQL Server'


def obtener_conexion():
    """Abre y devuelve una nueva conexión a la base de datos 'ventas'."""
    driver = os.environ.get('DB_DRIVER', '').strip() or DRIVER_POR_DEFECTO
    if driver not in pyodbc.drivers():
        # Mensaje claro en vez del IM002 genérico de Windows ("no se encuentra el origen de datos").
        instalados = [d for d in pyodbc.drivers() if 'SQL Server' in d]
        raise RuntimeError(
            f'No está instalado el driver "{driver}". '
            f'Drivers de SQL Server en esta PC: {instalados or "ninguno"}. '
            'Instala "ODBC Driver 17 (o 18) for SQL Server" (x64) o indica en el .env '
            'DB_DRIVER=<uno de los drivers instalados>.'
        )

    cadena_conexion = (
        f"DRIVER={{{driver}}};"
        f"SERVER={os.environ['DB_SERVER']};"
        f"DATABASE={os.environ['DB_NAME']};"
        f"UID={os.environ['DB_USER']};"
        f"PWD={os.environ['DB_PASSWORD']};"
        # Cifra todo el tráfico con el SQL Server del hosting (y valida su certificado).
        # Sin esto, ODBC Driver 17 conecta sin cifrar: las contraseñas que se envían
        # para calcular HASHBYTES viajarían en texto plano por internet (HU-05).
        "Encrypt=yes;"
    )
    return pyodbc.connect(cadena_conexion)
