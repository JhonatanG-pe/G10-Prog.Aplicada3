import os
from flask import Flask, redirect, url_for, flash, request
from dotenv import load_dotenv

from routes.administrador import admin_bp
from routes import catalogo      # registra rutas de categorías/marcas/productos en admin_bp
from routes import accesos       # registra rutas de perfiles/opciones de menú/asignación en admin_bp
from routes import proveedores   # registra rutas de proveedores en admin_bp
from routes import compras       # registra rutas de compras (reposición de stock) en admin_bp
from routes import reportes      # registra rutas de reportes en admin_bp
from routes import pedidos       # registra rutas de pedidos de la tienda (HU-20) en admin_bp
from routes.cliente import cliente_bp

load_dotenv()

app = Flask(__name__)
# Sin valor por defecto: con una clave conocida cualquiera podría falsificar
# la cookie de sesión y entrar como Administrador. Si falta en el .env, la app no arranca.
app.secret_key = os.environ['SECRET_KEY']

# Tope de cada envío de formulario: la foto (máx. 2 MB, HU-09) más el resto de campos.
# Sin este tope, un archivo enorme se recibiría completo antes de poder rechazarlo.
app.config['MAX_CONTENT_LENGTH'] = (catalogo.TAMANO_MAXIMO_IMAGEN_MB + 1) * 1024 * 1024


@app.errorhandler(413)
def envio_demasiado_grande(_error):
    flash(f'El archivo es demasiado grande. El tamaño máximo de la foto es {catalogo.TAMANO_MAXIMO_IMAGEN_MB} MB.', 'error')
    return redirect(request.url)


# Cada perfil tiene su propio módulo, con su propio login y sus propias vistas
app.register_blueprint(admin_bp)
app.register_blueprint(cliente_bp)


@app.route('/')
def inicio():
    # La raíz del sitio es la tienda pública (para el cliente). El personal
    # interno sigue entrando por su propia puerta: /admin/login.
    return redirect(url_for('cliente.tienda'))


if __name__ == '__main__':
    # El modo debug muestra código y permite ejecutar comandos desde el navegador
    # si ocurre un error: solo se activa en desarrollo, con FLASK_DEBUG=1 en el .env.
    app.run(debug=os.environ.get('FLASK_DEBUG') == '1')
