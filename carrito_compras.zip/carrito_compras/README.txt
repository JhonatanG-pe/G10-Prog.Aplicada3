===============================================================================
  SISTEMA DE CARRITO DE COMPRAS
  Panel interno (Administrador / Operador) + Tienda en línea (Cliente)
  Python 3.12 + Flask + SQL Server
===============================================================================

CONTENIDO DEL PROYECTO
----------------------
  app.py              Punto de entrada: arranca el sistema.
  db.py               Conexión a SQL Server (lee los datos del archivo .env).
  seguridad.py        Reglas de contraseñas (HASHBYTES + salt).
  crear_usuario.py    Script de consola para crear un usuario interno.
  routes/             Lógica del panel interno y de la tienda.
  templates/          Pantallas (HTML).
  static/uploads/     Fotos de los productos.
  docs/               Distribución de la revisión, criterio de terminado y seguridad (PDF).
  .env.example        Plantilla del archivo de configuración.
  requirements.txt    Librerías de Python (versiones exactas).


-------------------------------------------------------------------------------
1. QUÉ INSTALAR (una sola vez)
-------------------------------------------------------------------------------
  a) Python 3.12 (64 bits): https://www.python.org/downloads/
     Al instalar, marca la casilla "Add Python to PATH".
     (Python 3.14 también funciona; si alguna instalación falla, usa 3.12.)

  b) ODBC Driver 17 o 18 for SQL Server, versión x64 (de Microsoft).
     Busca en Google: "ODBC Driver 17 for SQL Server download".
     Para ver cuál tienes instalado, en PowerShell:
        Get-OdbcDriver | Where-Object Name -like "*SQL Server*" | Select-Object Name, Platform
     Sirven SOLO el 17 o el 18 (los antiguos "SQL Server" o "Native Client" no).


-------------------------------------------------------------------------------
2. PREPARAR EL PROYECTO (una sola vez)
-------------------------------------------------------------------------------
  Descomprime el ZIP, abre PowerShell dentro de la carpeta del proyecto y ejecuta:

     python -m venv venv
     venv\Scripts\Activate.ps1
     pip install -r requirements.txt

  Debe aparecer "(venv)" al inicio de la línea de comandos.

  Luego crea tu archivo de configuración:
     1. Copia ".env.example" y renombra la copia como ".env".
     2. Completa DB_SERVER, DB_NAME, DB_USER y DB_PASSWORD con los datos que te
        pase Ricardo por mensaje privado.
     3. En SECRET_KEY pon un texto largo y aleatorio. Para generarlo:
           python -c "import secrets; print(secrets.token_hex(32))"
     4. Si tienes el driver 18, agrega:  DB_DRIVER=ODBC Driver 18 for SQL Server

  IMPORTANTE: el archivo .env tiene contraseñas. No lo compartas ni lo subas a internet.


-------------------------------------------------------------------------------
3. LEVANTAR EL SISTEMA (cada vez que lo uses)
-------------------------------------------------------------------------------
     venv\Scripts\Activate.ps1
     python app.py

  Abre en el navegador:
     Tienda (clientes) ......... http://127.0.0.1:5000
     Panel interno ............. http://127.0.0.1:5000/admin/login

  Para detener el sistema: Ctrl + C en la terminal.
  Si cambias código, detén y vuelve a ejecutar "python app.py"
  (o pon FLASK_DEBUG=1 en tu .env para que se recargue solo).


-------------------------------------------------------------------------------
4. USUARIOS PARA PROBAR
-------------------------------------------------------------------------------
  - Panel interno: pídele a Ricardo un usuario (lo crea en Usuarios). Al entrar,
    elige el perfil con el que vas a trabajar (Administrador u Operador).
  - Tienda: crea tu propia cuenta de cliente con "Crear cuenta".
  - Usa datos de prueba propios para no pisar los de los demás
    (por ejemplo "Categoría Bryan" o el correo "jonathan.prueba@...").
  - No borres ni modifiques datos reales que no hayas creado tú.


-------------------------------------------------------------------------------
5. PROBLEMAS FRECUENTES
-------------------------------------------------------------------------------
  * "No se puede cargar el archivo ...\Activate.ps1 porque la ejecución de
    scripts está deshabilitada"
      Ejecuta una vez en PowerShell y responde "S":
         Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
      (O usa la terminal CMD y activa con:  venv\Scripts\activate.bat)

  * "IM002 ... No se encuentra el nombre del origen de datos"
    o "No está instalado el driver ..."
      Falta el ODBC Driver 17/18 x64, o el .env indica un driver que no tienes.
      Revisa el punto 1.b y la línea DB_DRIVER de tu .env.

  * "KeyError: 'SECRET_KEY'" o "KeyError: 'DB_SERVER'"
      Falta el archivo .env o le falta esa línea (punto 2).

  * Las fotos de algunos productos se ven rotas
      Las fotos se guardan en la PC de quien las subió (static/uploads/productos),
      pero la base de datos es compartida. Pide a quien la subió que te pase el
      archivo y cópialo en esa carpeta, o vuelve a subir la foto desde "Editar producto".


-------------------------------------------------------------------------------
6. CÓMO REVISAR LAS HISTORIAS DE USUARIO
-------------------------------------------------------------------------------
  - Tus historias asignadas están en docs/Distribucion_revision_HU.pdf
  - Cada tarjeta de Trello (tablero "Historias de Usuario") tiene sus criterios
    de aceptación y la checklist "Criterio de terminado" (docs/Criterio_de_terminado.pdf).
  - Prueba cada criterio, también con datos inválidos, guarda capturas como
    evidencia y marca la checklist. Si algo falla, coméntalo en la tarjeta.
