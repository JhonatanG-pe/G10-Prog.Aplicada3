"""
Módulo de PEDIDOS (HU-20): el personal ve los pedidos de la tienda (tabla Venta)
y actualiza su estado. Quién entra lo decide la opción de menú "Pedidos"
asignada a cada perfil en "Asignar Accesos" (acceso_requerido).

Ciclo de vida del pedido (columna Venta.Estado):
    Pendiente --> Entregado   (final)
    Pendiente --> Anulado     (final; devuelve el stock de cada producto)
"""
from flask import render_template, request, redirect, url_for, flash, current_app
from db import obtener_conexion
from routes.administrador import admin_bp, acceso_requerido

ESTADO_PENDIENTE = 'Pendiente'
ESTADO_ENTREGADO = 'Entregado'
ESTADO_ANULADO = 'Anulado'
ESTADOS = (ESTADO_PENDIENTE, ESTADO_ENTREGADO, ESTADO_ANULADO)


@admin_bp.route('/pedidos')
@acceso_requerido
def lista_pedidos():
    estado = request.args.get('estado', '').strip()
    # El filtro llega en la URL: solo se acepta uno de los estados conocidos.
    if estado and estado not in ESTADOS:
        flash('El estado elegido no es válido.', 'error')
        return redirect(url_for('admin.lista_pedidos'))

    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        f"""
        SELECT v.IdVenta, v.FechaVenta, cl.Nombres, cl.Apellidos, v.TotalProducto, v.MontoTotal, v.Estado
        FROM Venta v
        INNER JOIN Cliente cl ON cl.IdCliente = v.IdCliente
        {'WHERE v.Estado = ?' if estado else ''}
        ORDER BY v.FechaVenta DESC, v.IdVenta DESC
        """,
        *([estado] if estado else []),
    )
    pedidos = cursor.fetchall()
    conexion.close()
    return render_template('admin/pedidos.html', pedidos=pedidos, estados=ESTADOS, estado=estado)


@admin_bp.route('/pedidos/<int:id_venta>')
@acceso_requerido
def ver_pedido_admin(id_venta):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT v.IdVenta, v.FechaVenta, v.TotalProducto, v.MontoTotal, v.Contacto, v.Telefono,
               v.Direccion, v.Estado, cl.Nombres, cl.Apellidos, cl.Correo
        FROM Venta v
        INNER JOIN Cliente cl ON cl.IdCliente = v.IdCliente
        WHERE v.IdVenta = ?
        """,
        id_venta,
    )
    pedido = cursor.fetchone()
    if pedido is None:
        conexion.close()
        flash('El pedido no existe.', 'error')
        return redirect(url_for('admin.lista_pedidos'))

    cursor.execute(
        """
        SELECT p.Nombre, dv.Cantidad, dv.Precio, (dv.Cantidad * dv.Precio) AS Subtotal
        FROM Detalle_Venta dv
        INNER JOIN Producto p ON p.IdProducto = dv.IdProducto
        WHERE dv.IdVenta = ?
        ORDER BY p.Nombre
        """,
        id_venta,
    )
    detalle = cursor.fetchall()
    conexion.close()
    return render_template('admin/pedido_detalle.html', pedido=pedido, detalle=detalle,
                           pendiente=pedido.Estado == ESTADO_PENDIENTE)


@admin_bp.route('/pedidos/<int:id_venta>/estado', methods=['POST'])
@acceso_requerido
def cambiar_estado_pedido(id_venta):
    acciones = {'entregar': ESTADO_ENTREGADO, 'anular': ESTADO_ANULADO}
    nuevo_estado = acciones.get(request.form.get('accion', ''))
    if nuevo_estado is None:
        flash('La acción solicitada no es válida.', 'error')
        return redirect(url_for('admin.ver_pedido_admin', id_venta=id_venta))

    conexion = obtener_conexion()
    cursor = conexion.cursor()
    try:
        # Solo cambia si SIGUE en Pendiente (HU-20, criterio 4). La condición va en el
        # mismo UPDATE: si dos usuarios actúan a la vez, solo uno lo consigue.
        cursor.execute(
            "UPDATE Venta SET Estado = ? WHERE IdVenta = ? AND Estado = ?",
            nuevo_estado, id_venta, ESTADO_PENDIENTE,
        )
        if cursor.rowcount != 1:
            conexion.rollback()
            conexion.close()
            flash('Este pedido ya no está Pendiente: un pedido Entregado o Anulado no puede cambiar de estado.', 'error')
            return redirect(url_for('admin.ver_pedido_admin', id_venta=id_venta))

        if nuevo_estado == ESTADO_ANULADO:
            # HU-20, criterio 3: se devuelve el stock de cada producto, en la MISMA transacción.
            cursor.execute("SELECT IdProducto, Cantidad FROM Detalle_Venta WHERE IdVenta = ?", id_venta)
            for linea in cursor.fetchall():
                cursor.execute(
                    "UPDATE Producto SET Stock = Stock + ? WHERE IdProducto = ?",
                    linea.Cantidad, linea.IdProducto,
                )
                if cursor.rowcount != 1:
                    raise RuntimeError(f'No se pudo devolver el stock del producto {linea.IdProducto}.')

        conexion.commit()
    except Exception:
        conexion.rollback()
        conexion.close()
        current_app.logger.exception('Error al cambiar el estado del pedido %s', id_venta)
        flash('No se pudo actualizar el pedido; no se guardó ningún cambio. Inténtalo nuevamente.', 'error')
        return redirect(url_for('admin.ver_pedido_admin', id_venta=id_venta))

    conexion.close()
    if nuevo_estado == ESTADO_ANULADO:
        flash(f'Pedido N° {id_venta} anulado. El stock de sus productos fue devuelto.', 'success')
    else:
        flash(f'Pedido N° {id_venta} marcado como entregado.', 'success')
    return redirect(url_for('admin.ver_pedido_admin', id_venta=id_venta))
