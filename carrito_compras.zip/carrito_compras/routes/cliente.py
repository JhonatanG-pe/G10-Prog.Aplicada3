"""
Módulo del CLIENTE: catálogo público, registro, login, carrito y checkout.
Blueprint completamente separado del personal interno (routes/administrador.py):
tiene su propia tabla (Cliente, no Usuario), su propio login, y su propia
sesión. Un cliente jamás comparte perfiles con Administrador/Operador.

Las contraseñas de Cliente usan el mismo esquema que Usuario: HASHBYTES
('SHA2_256', clave + salt) nativo de SQL Server, nunca el hash calculado
en Python (columna Clave VARBINARY(32) + columna Salt VARCHAR(32), ya
migradas por migracion_hashbytes.sql).
"""
import re
from functools import wraps
from datetime import datetime
from decimal import Decimal
import pyodbc
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, current_app
from db import obtener_conexion
from seguridad import (SQL_HASH_CLAVE, SQL_HASH_CLAVE_CON_SALT_GUARDADA, validar_clave_nueva,
                       clave_ingresada_es_comparable, generar_salt_unica)

cliente_bp = Blueprint('cliente', __name__, url_prefix='/cliente')

MONTO_MAXIMO_VENTA = Decimal('99999999.99')  # columna Venta.MontoTotal DECIMAL(10,2)


def cliente_requerido(vista):
    """Protege una vista: solo un Cliente logueado puede pasar (nunca Administrador/Operador)."""
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if not session.get('id_cliente'):
            flash('Debes iniciar sesión para continuar.', 'error')
            return redirect(url_for('cliente.login'))
        return vista(*args, **kwargs)
    return envoltura


# ==========================================================================
# CATÁLOGO PÚBLICO (no requiere login: cualquiera puede ver la tienda)
# ==========================================================================
@cliente_bp.route('/tienda')
def tienda():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT p.IdProducto, p.Nombre, p.Descripcion, p.Precio, p.Stock, p.RutaImagen,
               c.Descripcion AS Categoria, m.Descripcion AS Marca
        FROM Producto p
        LEFT JOIN Categoria c ON c.IdCategoria = p.IdCategoria
        LEFT JOIN Marca m ON m.IdMarca = p.IdMarca
        WHERE p.Activo = 1
        ORDER BY p.Nombre
        """
    )
    productos = cursor.fetchall()
    conexion.close()
    return render_template('cliente/tienda.html', productos=productos)


# ==========================================================================
# REGISTRO
# ==========================================================================
@cliente_bp.route('/registro', methods=['GET', 'POST'])
def registro():
    if request.method == 'POST':
        datos = _leer_datos_personales()
        nombres, apellidos, telefono, domicilio = datos['nombres'], datos['apellidos'], datos['telefono'], datos['domicilio']
        correo = request.form.get('correo', '').strip()
        clave = request.form.get('clave', '')
        clave_confirmar = request.form.get('clave_confirmar', '')

        # El HTML ya restringe estos formatos, pero se vuelven a validar aquí porque
        # el navegador se puede saltar (formulario editado a mano, petición directa, etc.).
        error = datos['error']
        if not error and (not correo or not clave):
            error = 'Completa todos los campos obligatorios.'
        elif not error and (not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', correo) or len(correo) > 100):
            error = 'Ingresa un correo electrónico válido.'
        elif not error:
            error = validar_clave_nueva(clave, clave_confirmar)
        if error:
            flash(error, 'error')
            return render_template('cliente/registro.html')

        conexion = obtener_conexion()
        cursor = conexion.cursor()

        cursor.execute("SELECT 1 FROM Cliente WHERE Correo = ?", correo)
        if cursor.fetchone():
            conexion.close()
            flash('Ya existe una cuenta con ese correo.', 'error')
            return render_template('cliente/registro.html')

        # Salt única de 32 caracteres; el hash real lo calcula SQL Server con
        # HASHBYTES, nunca Python (mismo esquema que Usuario, ver seguridad.py).
        try:
            salt = generar_salt_unica(cursor)
            cursor.execute(
                f"""
                INSERT INTO Cliente (Nombres, Apellidos, Correo, Clave, Salt, Telefono, Domicilio, Activo, FechaRegistro)
                OUTPUT INSERTED.IdCliente
                VALUES (?, ?, ?, {SQL_HASH_CLAVE}, ?, ?, ?, 1, ?)
                """,
                nombres, apellidos, correo, clave, salt, salt, telefono, domicilio, datetime.now(),
            )
            conexion.commit()
        except pyodbc.IntegrityError:
            # Dos registros simultáneos con el mismo correo: el índice único
            # UQ_Cliente_Correo de la BD rechaza el segundo (HU-13, criterio 2).
            conexion.rollback()
            conexion.close()
            flash('Ya existe una cuenta con ese correo.', 'error')
            return render_template('cliente/registro.html')
        conexion.close()
        flash('Cuenta creada correctamente. Ya puedes iniciar sesión.', 'success')
        return redirect(url_for('cliente.login'))

    return render_template('cliente/registro.html')


def _leer_datos_personales():
    """
    Nombres y apellidos (obligatorios, máx. 100), teléfono (opcional, 6 a 12 dígitos)
    y dirección (opcional, máx. 200): límites de las columnas de Cliente.
    Mismas reglas en el registro (HU-13) y en "Mi cuenta" (HU-21).
    """
    datos = {
        'nombres': ' '.join(request.form.get('nombres', '').split()),
        'apellidos': ' '.join(request.form.get('apellidos', '').split()),
        'telefono': request.form.get('telefono', '').strip() or None,
        'domicilio': ' '.join(request.form.get('domicilio', '').split()) or None,
        'error': None,
    }
    if not datos['nombres'] or not datos['apellidos']:
        datos['error'] = 'Completa todos los campos obligatorios.'
    elif len(datos['nombres']) > 100 or len(datos['apellidos']) > 100:
        datos['error'] = 'Nombres y apellidos admiten máximo 100 caracteres.'
    elif datos['telefono'] and not re.fullmatch(r'\d{6,12}', datos['telefono']):
        datos['error'] = 'El teléfono debe tener entre 6 y 12 dígitos numéricos.'
    elif datos['domicilio'] and len(datos['domicilio']) > 200:
        datos['error'] = 'La dirección admite máximo 200 caracteres.'
    return datos


# ==========================================================================
# LOGIN / LOGOUT
# ==========================================================================
@cliente_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form.get('correo', '').strip()
        clave_ingresada = request.form.get('clave', '')

        if not correo or not clave_ingresada_es_comparable(clave_ingresada):
            flash('Correo o contraseña incorrectos.', 'error')
            return render_template('cliente/login.html')

        # El hash se recalcula en SQL Server con la salt guardada del cliente;
        # Python nunca ve el hash real ni registra la contraseña en ningún log.
        conexion = obtener_conexion()
        cursor = conexion.cursor()
        cursor.execute(
            f"SELECT IdCliente, Nombres, Activo FROM Cliente "
            f"WHERE Correo = ? AND Clave = {SQL_HASH_CLAVE_CON_SALT_GUARDADA}",
            correo, clave_ingresada,
        )
        fila = cursor.fetchone()
        conexion.close()

        # Mismo mensaje si el correo no existe o la clave es incorrecta.
        if fila is None:
            flash('Correo o contraseña incorrectos.', 'error')
            return render_template('cliente/login.html')

        id_cliente, nombres, activo = fila

        # El estado se revela solo a quien ya demostró conocer la contraseña.
        if not activo:
            flash('Esta cuenta está inactiva.', 'error')
            return render_template('cliente/login.html')

        session.clear()  # cierra cualquier sesión anterior (de Administrador/Operador u otro cliente)
        session['id_cliente'] = id_cliente
        session['nombre_cliente'] = nombres

        return redirect(url_for('cliente.tienda'))

    return render_template('cliente/login.html')


@cliente_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('cliente.tienda'))


# ==========================================================================
# CARRITO
# ==========================================================================
@cliente_bp.route('/carrito/agregar/<int:id_producto>', methods=['POST'])
@cliente_requerido
def agregar_al_carrito(id_producto):
    cantidad = _leer_cantidad()
    if cantidad is None:
        flash('La cantidad debe ser un número entero mayor que 0.', 'error')
        return redirect(url_for('cliente.tienda'))

    conexion = obtener_conexion()
    cursor = conexion.cursor()

    # El id llega desde la URL: nunca confiar en él. Solo se pueden agregar
    # productos que existan y estén activos (no dados de baja por el personal).
    cursor.execute(
        "SELECT Nombre, Stock FROM Producto WHERE IdProducto = ? AND Activo = 1",
        id_producto,
    )
    producto = cursor.fetchone()
    if producto is None:
        conexion.close()
        flash('El producto no existe o ya no está disponible.', 'error')
        return redirect(url_for('cliente.tienda'))

    # ¿Ya tiene este producto en el carrito? si sí, solo aumenta la cantidad.
    cursor.execute(
        "SELECT IdCarrito, Cantidad FROM Carrito WHERE IdCliente = ? AND IdProducto = ?",
        session['id_cliente'], id_producto,
    )
    fila = cursor.fetchone()

    cantidad_final = cantidad + (fila.Cantidad if fila else 0)
    if cantidad_final > producto.Stock:
        conexion.close()
        ya_tiene = f' Ya tienes {fila.Cantidad} en tu carrito.' if fila else ''
        flash(f'No hay suficiente stock de "{producto.Nombre}" (disponible: {producto.Stock}).{ya_tiene}', 'error')
        return redirect(url_for('cliente.tienda'))

    if fila:
        cursor.execute(
            "UPDATE Carrito SET Cantidad = ? WHERE IdCarrito = ?",
            fila.Cantidad + cantidad, fila.IdCarrito,
        )
    else:
        cursor.execute(
            "INSERT INTO Carrito (IdCliente, IdProducto, Cantidad) VALUES (?, ?, ?)",
            session['id_cliente'], id_producto, cantidad,
        )

    conexion.commit()
    conexion.close()
    flash('Producto agregado al carrito.', 'success')
    return redirect(url_for('cliente.tienda'))


@cliente_bp.route('/carrito')
@cliente_requerido
def ver_carrito():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT ca.IdCarrito, p.IdProducto, p.Nombre, p.Precio, p.RutaImagen, p.Stock,
               ca.Cantidad, (p.Precio * ca.Cantidad) AS Subtotal
        FROM Carrito ca
        INNER JOIN Producto p ON p.IdProducto = ca.IdProducto
        WHERE ca.IdCliente = ?
        ORDER BY p.Nombre
        """,
        session['id_cliente'],
    )
    items = cursor.fetchall()
    conexion.close()

    total = sum(i.Subtotal for i in items) if items else 0
    return render_template('cliente/carrito.html', items=items, total=total)


@cliente_bp.route('/carrito/actualizar/<int:id_carrito>', methods=['POST'])
@cliente_requerido
def actualizar_carrito(id_carrito):
    cantidad = _leer_cantidad()
    if cantidad is None:
        flash('La cantidad debe ser un número entero mayor que 0. Para quitar el producto usa "Quitar".', 'error')
        return redirect(url_for('cliente.ver_carrito'))

    conexion = obtener_conexion()
    cursor = conexion.cursor()
    # Solo un ítem del propio carrito del cliente (el IdCarrito llega en la URL).
    cursor.execute(
        """
        SELECT p.Nombre, p.Stock FROM Carrito ca
        INNER JOIN Producto p ON p.IdProducto = ca.IdProducto
        WHERE ca.IdCarrito = ? AND ca.IdCliente = ?
        """,
        id_carrito, session['id_cliente'],
    )
    item = cursor.fetchone()
    if item is None:
        conexion.close()
        flash('Ese producto ya no está en tu carrito.', 'error')
        return redirect(url_for('cliente.ver_carrito'))

    # HU-15: la cantidad no puede exceder el stock disponible del producto.
    if cantidad > item.Stock:
        conexion.close()
        flash(f'No puedes pedir {cantidad} de "{item.Nombre}": solo hay {item.Stock} disponible(s).', 'error')
        return redirect(url_for('cliente.ver_carrito'))

    cursor.execute(
        "UPDATE Carrito SET Cantidad = ? WHERE IdCarrito = ? AND IdCliente = ?",
        cantidad, id_carrito, session['id_cliente'],
    )
    conexion.commit()
    conexion.close()
    flash(f'Cantidad de "{item.Nombre}" actualizada.', 'success')
    return redirect(url_for('cliente.ver_carrito'))


@cliente_bp.route('/carrito/eliminar/<int:id_carrito>', methods=['POST'])
@cliente_requerido
def eliminar_del_carrito(id_carrito):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    # Solo se borra ESE ítem y solo si es del propio cliente: los demás no se tocan (HU-15).
    cursor.execute(
        "DELETE FROM Carrito WHERE IdCarrito = ? AND IdCliente = ?",
        id_carrito, session['id_cliente'],
    )
    borrado = cursor.rowcount
    conexion.commit()
    conexion.close()
    if borrado:
        flash('Producto quitado del carrito.', 'success')
    else:
        flash('Ese producto ya no está en tu carrito.', 'error')
    return redirect(url_for('cliente.ver_carrito'))


def _leer_cantidad():
    """Cantidad enviada en el formulario: entero de 1 en adelante (columna INT), o None si no es válida."""
    cantidad = request.form.get('cantidad', '').strip()
    if not re.fullmatch(r'\d{1,9}', cantidad) or int(cantidad) == 0:
        return None
    return int(cantidad)


# ==========================================================================
# CHECKOUT
# ==========================================================================
@cliente_bp.route('/carrito/finalizar', methods=['GET', 'POST'])
@cliente_requerido
def finalizar_compra():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT ca.IdCarrito, p.IdProducto, p.Nombre, p.Precio, p.Stock, p.Activo, ca.Cantidad
        FROM Carrito ca
        INNER JOIN Producto p ON p.IdProducto = ca.IdProducto
        WHERE ca.IdCliente = ?
        """,
        session['id_cliente'],
    )
    items = cursor.fetchall()

    if not items:
        conexion.close()
        flash('Tu carrito está vacío.', 'error')
        return redirect(url_for('cliente.tienda'))

    total = sum((i.Precio * i.Cantidad for i in items), Decimal('0'))

    if request.method == 'POST':
        contacto = ' '.join(request.form.get('contacto', '').split())
        telefono = request.form.get('telefono', '').strip() or None
        direccion = ' '.join(request.form.get('direccion', '').split())

        # HU-16: datos de entrega completos. Límites = columnas de la tabla Venta.
        # El HTML ya los restringe, pero se validan aquí porque el navegador se puede saltar.
        error = None
        if not contacto or not direccion:
            error = 'El nombre de contacto y la dirección de entrega son obligatorios.'
        elif len(contacto) > 100:
            error = 'El nombre de contacto admite máximo 100 caracteres.'
        elif len(direccion) > 300:
            error = 'La dirección admite máximo 300 caracteres.'
        elif telefono and not re.fullmatch(r'\d{6,12}', telefono):
            error = 'El teléfono debe tener entre 6 y 12 dígitos numéricos.'
        elif total > MONTO_MAXIMO_VENTA:
            error = f'El total del pedido supera el máximo permitido (S/ {MONTO_MAXIMO_VENTA}).'
        if error:
            conexion.close()
            flash(error, 'error')
            return render_template('cliente/checkout.html', items=items, total=total, entrega=request.form)

        # Revalida el stock antes de confirmar: puede haber cambiado desde
        # que se agregó al carrito (otro cliente pudo haberlo comprado antes).
        for item in items:
            # El personal pudo dar de baja el producto después de que se agregó al carrito.
            if not item.Activo:
                conexion.close()
                flash(f'"{item.Nombre}" ya no está disponible. Quítalo del carrito para continuar.', 'error')
                return redirect(url_for('cliente.ver_carrito'))
            if item.Cantidad > item.Stock:
                conexion.close()
                flash(f'No hay suficiente stock de "{item.Nombre}" (disponible: {item.Stock}).', 'error')
                return redirect(url_for('cliente.ver_carrito'))

        total_producto = sum(i.Cantidad for i in items)

        try:
            cursor.execute(
                """
                INSERT INTO Venta (IdCliente, TotalProducto, MontoTotal, Contacto, Telefono, Direccion, FechaVenta, Estado)
                OUTPUT INSERTED.IdVenta
                VALUES (?, ?, ?, ?, ?, ?, ?, 'Pendiente')
                """,
                session['id_cliente'], total_producto, total, contacto, telefono, direccion, datetime.now(),
            )
            id_venta = cursor.fetchone()[0]

            for item in items:
                cursor.execute(
                    "INSERT INTO Detalle_Venta (IdVenta, IdProducto, Cantidad, Precio) VALUES (?, ?, ?, ?)",
                    id_venta, item.IdProducto, item.Cantidad, item.Precio,
                )
                # Descuenta el stock vendido — mismo principio que la reposición en Compras, pero al revés.
                # El "AND Stock >= ?" hace que SQL Server verifique y descuente en un solo paso:
                # si otro cliente compró las últimas unidades entre la revalidación de arriba y
                # este UPDATE, no se actualiza ninguna fila y se anula toda la venta.
                cursor.execute(
                    "UPDATE Producto SET Stock = Stock - ? WHERE IdProducto = ? AND Activo = 1 AND Stock >= ?",
                    item.Cantidad, item.IdProducto, item.Cantidad,
                )
                if cursor.rowcount == 0:
                    conexion.rollback()
                    conexion.close()
                    flash(f'"{item.Nombre}" ya no tiene stock suficiente o dejó de estar disponible; revisa tu carrito.', 'error')
                    return redirect(url_for('cliente.ver_carrito'))

            # HU-16: el carrito queda vacío. Se borran exactamente los ítems que se vendieron:
            # si no coinciden (ej. doble clic en "Confirmar" y el primer pedido ya vació el
            # carrito), se anula esta venta para no registrar el mismo pedido dos veces.
            cursor.execute("DELETE FROM Carrito WHERE IdCliente = ?", session['id_cliente'])
            if cursor.rowcount != len(items):
                conexion.rollback()
                conexion.close()
                flash('Tu carrito cambió mientras se confirmaba el pedido. Revísalo e inténtalo de nuevo.', 'error')
                return redirect(url_for('cliente.ver_carrito'))
            conexion.commit()
            conexion.close()
            flash(f'¡Compra realizada correctamente! N° de pedido: {id_venta}', 'success')
            return redirect(url_for('cliente.tienda'))
        except Exception:
            conexion.rollback()
            conexion.close()
            # El detalle técnico va al log del servidor, nunca a la pantalla del cliente.
            current_app.logger.exception('Error al procesar la compra del cliente %s', session['id_cliente'])
            flash('No se pudo procesar la compra. Inténtalo nuevamente en unos minutos.', 'error')
            return redirect(url_for('cliente.ver_carrito'))

    # Se proponen los datos que el cliente ya registró (los puede cambiar para esta entrega).
    cursor.execute("SELECT Nombres, Apellidos, Telefono, Domicilio FROM Cliente WHERE IdCliente = ?", session['id_cliente'])
    cliente = cursor.fetchone()
    conexion.close()
    entrega = {
        'contacto': f'{cliente.Nombres} {cliente.Apellidos}',
        'telefono': cliente.Telefono or '',
        'direccion': cliente.Domicilio or '',
    }
    return render_template('cliente/checkout.html', items=items, total=total, entrega=entrega)


# ==========================================================================
# HU-19: MIS PEDIDOS
# ==========================================================================
@cliente_bp.route('/pedidos')
@cliente_requerido
def mis_pedidos():
    """Solo los pedidos del cliente de la sesión, del más reciente al más antiguo."""
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT IdVenta, FechaVenta, TotalProducto, MontoTotal, Estado
        FROM Venta
        WHERE IdCliente = ?
        ORDER BY FechaVenta DESC, IdVenta DESC
        """,
        session['id_cliente'],
    )
    pedidos = cursor.fetchall()
    conexion.close()
    return render_template('cliente/mis_pedidos.html', pedidos=pedidos)


@cliente_bp.route('/pedidos/<int:id_venta>')
@cliente_requerido
def ver_pedido(id_venta):
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    # El filtro por IdCliente impide ver el pedido de otro cliente cambiando el
    # número en la URL (HU-19, criterio 3): para él ese pedido "no existe".
    cursor.execute(
        """
        SELECT IdVenta, FechaVenta, TotalProducto, MontoTotal, Contacto, Telefono, Direccion, Estado
        FROM Venta WHERE IdVenta = ? AND IdCliente = ?
        """,
        id_venta, session['id_cliente'],
    )
    pedido = cursor.fetchone()
    if pedido is None:
        conexion.close()
        flash('Ese pedido no existe o no te pertenece.', 'error')
        return redirect(url_for('cliente.mis_pedidos'))

    cursor.execute(
        """
        SELECT p.Nombre, p.RutaImagen, dv.Cantidad, dv.Precio, (dv.Cantidad * dv.Precio) AS Subtotal
        FROM Detalle_Venta dv
        INNER JOIN Producto p ON p.IdProducto = dv.IdProducto
        WHERE dv.IdVenta = ?
        ORDER BY p.Nombre
        """,
        id_venta,
    )
    detalle = cursor.fetchall()
    conexion.close()
    return render_template('cliente/pedido_detalle.html', pedido=pedido, detalle=detalle)


# ==========================================================================
# HU-21: MI CUENTA
# ==========================================================================
@cliente_bp.route('/cuenta', methods=['GET', 'POST'])
@cliente_requerido
def mi_cuenta():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        "SELECT Nombres, Apellidos, Correo, Telefono, Domicilio FROM Cliente WHERE IdCliente = ?",
        session['id_cliente'],
    )
    cliente = cursor.fetchone()

    if request.method == 'POST':
        datos = _leer_datos_personales()
        if datos['error']:
            conexion.close()
            flash(datos['error'], 'error')
            return render_template('cliente/mi_cuenta.html', cliente=cliente, datos=request.form)

        # El correo NO se actualiza (HU-21): aunque se envíe en el formulario, se ignora.
        cursor.execute(
            "UPDATE Cliente SET Nombres = ?, Apellidos = ?, Telefono = ?, Domicilio = ? WHERE IdCliente = ?",
            datos['nombres'], datos['apellidos'], datos['telefono'], datos['domicilio'], session['id_cliente'],
        )
        conexion.commit()
        conexion.close()
        session['nombre_cliente'] = datos['nombres']   # el nombre actualizado se ve en la sesión
        flash('Tus datos se actualizaron correctamente.', 'success')
        return redirect(url_for('cliente.mi_cuenta'))

    conexion.close()
    return render_template('cliente/mi_cuenta.html', cliente=cliente, datos=None)


@cliente_bp.route('/cuenta/clave', methods=['POST'])
@cliente_requerido
def cambiar_clave():
    clave_actual = request.form.get('clave_actual', '')
    clave_nueva = request.form.get('clave_nueva', '')
    clave_confirmar = request.form.get('clave_confirmar', '')

    if not clave_actual or not clave_ingresada_es_comparable(clave_actual):
        flash('La contraseña actual es incorrecta.', 'error')
        return redirect(url_for('cliente.mi_cuenta'))
    error = validar_clave_nueva(clave_nueva, clave_confirmar)
    if error:
        flash(error, 'error')
        return redirect(url_for('cliente.mi_cuenta'))

    conexion = obtener_conexion()
    cursor = conexion.cursor()
    # La contraseña actual se verifica recalculando el HASHBYTES en SQL Server (HU-05).
    cursor.execute(
        f"SELECT 1 FROM Cliente WHERE IdCliente = ? AND Clave = {SQL_HASH_CLAVE_CON_SALT_GUARDADA}",
        session['id_cliente'], clave_actual,
    )
    if cursor.fetchone() is None:
        conexion.close()
        flash('La contraseña actual es incorrecta.', 'error')
        return redirect(url_for('cliente.mi_cuenta'))

    # Contraseña nueva con HASHBYTES y una salt NUEVA (HU-21, criterio 2).
    salt = generar_salt_unica(cursor)
    cursor.execute(
        f"UPDATE Cliente SET Clave = {SQL_HASH_CLAVE}, Salt = ? WHERE IdCliente = ?",
        clave_nueva, salt, salt, session['id_cliente'],
    )
    conexion.commit()
    conexion.close()
    flash('Tu contraseña se cambió correctamente.', 'success')
    return redirect(url_for('cliente.mi_cuenta'))
