"""
Módulo de REPORTES, EXCLUSIVO del perfil Administrador:
  HU-12: bajo stock, valorización de inventario e historial de compras.
  HU-17: ventas y productos más vendidos.
Cada ruta exige la opción Reportes asignada (acceso_requerido) Y además el perfil
Administrador (solo_perfil_administrador): un Operador no entra ni escribiendo la URL.
"""
from datetime import datetime, timedelta
from decimal import Decimal
from functools import wraps
from flask import render_template, request, flash, session, redirect, url_for
from db import obtener_conexion
from routes.administrador import admin_bp, acceso_requerido, ID_PERFIL_ADMINISTRADOR
from routes.pedidos import ESTADO_ANULADO


def solo_perfil_administrador(vista):
    """
    HU-12 y HU-17: los reportes son EXCLUSIVOS del perfil Administrador. Además de
    tener asignada la opción Reportes (acceso_requerido), el perfil de la sesión debe
    ser el de Administrador. Otro perfil con Reportes asignado no puede verlos.
    """
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if session.get('id_perfil') != ID_PERFIL_ADMINISTRADOR:
            flash('Los reportes son exclusivos del perfil Administrador.', 'error')
            return redirect(url_for('admin.panel'))
        return vista(*args, **kwargs)
    return envoltura


@admin_bp.route('/reportes')
@acceso_requerido
@solo_perfil_administrador
def reportes_index():
    return render_template('admin/reportes_index.html')


@admin_bp.route('/reportes/bajo-stock')
@acceso_requerido
@solo_perfil_administrador
def reporte_bajo_stock():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT p.IdProducto, p.Nombre, c.Descripcion AS Categoria, m.Descripcion AS Marca,
               p.Stock, p.StockMinimo
        FROM Producto p
        LEFT JOIN Categoria c ON c.IdCategoria = p.IdCategoria
        LEFT JOIN Marca m ON m.IdMarca = p.IdMarca
        -- HU-12: únicamente los productos con Stock en o por debajo de su mínimo definido.
        -- Los productos inactivos no se incluyen (ninguna historia pide mostrarlos).
        WHERE p.Activo = 1 AND p.Stock <= p.StockMinimo
        ORDER BY p.Stock ASC, p.Nombre
        """
    )
    productos = cursor.fetchall()
    conexion.close()
    return render_template('admin/reporte_bajo_stock.html', productos=productos)


@admin_bp.route('/reportes/valorizacion')
@acceso_requerido
@solo_perfil_administrador
def reporte_valorizacion():
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        -- HU-12: valor por producto = Stock x Precio, sobre el inventario actual.
        -- Los productos inactivos no se incluyen (ninguna historia pide mostrarlos).
        SELECT p.IdProducto, p.Nombre, c.Descripcion AS Categoria, p.Stock, p.Precio,
               (p.Stock * p.Precio) AS ValorTotal
        FROM Producto p
        LEFT JOIN Categoria c ON c.IdCategoria = p.IdCategoria
        WHERE p.Activo = 1
        ORDER BY ValorTotal DESC, p.Nombre
        """
    )
    productos = cursor.fetchall()
    # Precio es DECIMAL: la suma se hace en Decimal (exacta), sin pasar por float.
    valor_general = sum((p.ValorTotal for p in productos), Decimal('0'))
    conexion.close()
    return render_template('admin/reporte_valorizacion.html', productos=productos, valor_general=valor_general)


@admin_bp.route('/reportes/compras')
@acceso_requerido
@solo_perfil_administrador
def reporte_historial_compras():
    """HU-12: historial de compras, filtrable por proveedor y/o rango de fechas (ambos opcionales)."""
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    # Todos los proveedores (también los anulados): sus compras siguen en el historial.
    cursor.execute("SELECT IdProveedor, RazonSocial, Activo FROM Proveedor ORDER BY RazonSocial")
    proveedores = cursor.fetchall()

    filtros = {
        'id_proveedor': request.args.get('id_proveedor', '').strip(),
        'desde': request.args.get('desde', '').strip(),
        'hasta': request.args.get('hasta', '').strip(),
    }
    error = _validar_filtros_compras(filtros, proveedores)
    if error:
        conexion.close()
        flash(error, 'error')
        return render_template('admin/reporte_compras.html', compras=[], total_general=Decimal('0'),
                               proveedores=proveedores, filtros=filtros)

    condiciones, parametros = _condiciones_rango_fechas(filtros, 'c.Fecha')
    if filtros['id_proveedor']:
        condiciones.append('c.IdProveedor = ?')
        parametros.append(int(filtros['id_proveedor']))

    cursor.execute(
        f"""
        SELECT c.IdCompra, c.Fecha, pr.RazonSocial, c.Total, u.Nombres, u.ApellidoPaterno
        FROM Compra c
        INNER JOIN Proveedor pr ON pr.IdProveedor = c.IdProveedor
        LEFT JOIN Usuario u ON u.IdUsuario = c.IdUsuario
        {('WHERE ' + ' AND '.join(condiciones)) if condiciones else ''}
        ORDER BY c.Fecha DESC
        """,
        *parametros,
    )
    compras = cursor.fetchall()
    total_general = sum((c.Total for c in compras), Decimal('0'))
    conexion.close()
    return render_template('admin/reporte_compras.html', compras=compras, total_general=total_general,
                           proveedores=proveedores, filtros=filtros)


def _validar_filtros_compras(filtros, proveedores):
    """Valida los filtros del historial (vienen en la URL: se pueden escribir a mano)."""
    if filtros['id_proveedor'] and (not filtros['id_proveedor'].isdigit()
                                    or int(filtros['id_proveedor']) not in {p.IdProveedor for p in proveedores}):
        return 'El proveedor seleccionado no existe.'
    return _validar_rango_fechas(filtros)


def _validar_rango_fechas(filtros):
    """Fechas 'desde'/'hasta' opcionales en formato AAAA-MM-DD, y desde <= hasta."""
    fechas = {}
    for campo, nombre in (('desde', 'Desde'), ('hasta', 'Hasta')):
        if filtros[campo]:
            try:
                fechas[campo] = datetime.strptime(filtros[campo], '%Y-%m-%d')
            except ValueError:
                return f'La fecha "{nombre}" no es válida.'
    if len(fechas) == 2 and fechas['desde'] > fechas['hasta']:
        return 'La fecha "Desde" no puede ser posterior a la fecha "Hasta".'
    return None


def _condiciones_rango_fechas(filtros, columna):
    """Arma el WHERE de un rango de fechas ya validado. 'Hasta' incluye todo ese día."""
    condiciones, parametros = [], []
    if filtros['desde']:
        condiciones.append(f'{columna} >= ?')
        parametros.append(datetime.strptime(filtros['desde'], '%Y-%m-%d'))
    if filtros['hasta']:
        condiciones.append(f'{columna} < ?')
        parametros.append(datetime.strptime(filtros['hasta'], '%Y-%m-%d') + timedelta(days=1))
    return condiciones, parametros


# ==========================================================================
# HU-17: VENTAS (exclusivo del perfil Administrador)
# ==========================================================================

@admin_bp.route('/reportes/ventas')
@acceso_requerido
@solo_perfil_administrador
def reporte_ventas():
    """HU-17: ventas registradas por el checkout (Venta), filtrables por fecha y/o cliente."""
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute("SELECT IdCliente, Nombres, Apellidos, Correo FROM Cliente ORDER BY Nombres, Apellidos")
    clientes = cursor.fetchall()

    filtros = {
        'id_cliente': request.args.get('id_cliente', '').strip(),
        'desde': request.args.get('desde', '').strip(),
        'hasta': request.args.get('hasta', '').strip(),
    }
    error = None
    if filtros['id_cliente'] and (not filtros['id_cliente'].isdigit()
                                  or int(filtros['id_cliente']) not in {c.IdCliente for c in clientes}):
        error = 'El cliente seleccionado no existe.'
    error = error or _validar_rango_fechas(filtros)
    if error:
        conexion.close()
        flash(error, 'error')
        return render_template('admin/reporte_ventas.html', ventas=[], total_general=Decimal('0'),
                               total_unidades=0, clientes=clientes, filtros=filtros)

    condiciones, parametros = _condiciones_rango_fechas(filtros, 'v.FechaVenta')
    # HU-17, criterio 3: los pedidos anulados (HU-20) no cuentan en el reporte ni en sus totales.
    condiciones.append('v.Estado <> ?')
    parametros.append(ESTADO_ANULADO)
    if filtros['id_cliente']:
        condiciones.append('v.IdCliente = ?')
        parametros.append(int(filtros['id_cliente']))

    cursor.execute(
        f"""
        SELECT v.IdVenta, v.FechaVenta, cl.Nombres, cl.Apellidos, v.TotalProducto, v.MontoTotal, v.Estado
        FROM Venta v
        INNER JOIN Cliente cl ON cl.IdCliente = v.IdCliente
        {('WHERE ' + ' AND '.join(condiciones)) if condiciones else ''}
        ORDER BY v.FechaVenta DESC
        """,
        *parametros,
    )
    ventas = cursor.fetchall()
    conexion.close()
    return render_template('admin/reporte_ventas.html', ventas=ventas, clientes=clientes, filtros=filtros,
                           total_general=sum((v.MontoTotal for v in ventas), Decimal('0')),
                           total_unidades=sum(v.TotalProducto for v in ventas))


@admin_bp.route('/reportes/mas-vendidos')
@acceso_requerido
@solo_perfil_administrador
def reporte_mas_vendidos():
    """HU-17: ranking de productos más vendidos (por unidades), desde Detalle_Venta."""
    conexion = obtener_conexion()
    cursor = conexion.cursor()
    cursor.execute(
        """
        SELECT p.IdProducto, p.Nombre, c.Descripcion AS Categoria, m.Descripcion AS Marca,
               SUM(dv.Cantidad) AS Unidades,
               SUM(dv.Cantidad * dv.Precio) AS Importe,
               COUNT(DISTINCT dv.IdVenta) AS Ventas
        FROM Detalle_Venta dv
        INNER JOIN Venta v ON v.IdVenta = dv.IdVenta
        INNER JOIN Producto p ON p.IdProducto = dv.IdProducto
        LEFT JOIN Categoria c ON c.IdCategoria = p.IdCategoria
        LEFT JOIN Marca m ON m.IdMarca = p.IdMarca
        -- HU-17, criterio 3: los pedidos anulados (HU-20) no cuentan en el ranking.
        WHERE v.Estado <> ?
        GROUP BY p.IdProducto, p.Nombre, c.Descripcion, m.Descripcion
        ORDER BY Unidades DESC, Importe DESC, p.Nombre
        """,
        ESTADO_ANULADO,
    )
    ranking = cursor.fetchall()
    conexion.close()
    return render_template('admin/reporte_mas_vendidos.html', ranking=ranking)
